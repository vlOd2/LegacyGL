﻿namespace LGLBindingsGen
{
    public class Parameter
    {
        public string Name;
        public string Type;
        public bool IsPointer;
    }
}
