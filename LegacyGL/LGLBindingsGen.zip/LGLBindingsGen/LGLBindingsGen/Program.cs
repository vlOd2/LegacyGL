﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;

namespace LGLBindingsGen
{
    internal class Program
    {
        private static readonly string[] ALLOWED_FEATURES = new string[]
        {
            "GL_VERSION_1_0",
            "GL_VERSION_1_1"
        };

        private static readonly string[] RESERVED_KEYWORDS = new string[]
        {
            "abstract", "as", "base", "bool",
            "break", "byte", "case", "catch",
            "char", "checked", "class", "const",
            "continue", "decimal", "default", "delegate",
            "do", "double", "else", "enum",
            "event", "explicit", "extern", "false",
            "finally", "fixed", "float", "for",
            "foreach", "goto", "if", "implicit",
            "in", "int", "interface", "internal",
            "is", "lock", "long", "namespace",
            "new", "null", "object", "operator",
            "out", "override", "params", "private",
            "protected", "public", "readonly", "ref",
            "return", "sbyte", "sealed", "short",
            "sizeof", "stackalloc", "static", "string",
            "struct", "switch", "this", "throw",
            "true", "try", "typeof", "uint",
            "ulong", "unchecked", "unsafe", "ushort",
            "using", "virtual", "void", "volatile", "while"
        };

        private static string ConvertType(string type, out bool noPtr) 
        {
            noPtr = false;

            switch (type) 
            {
                case "GLenum": return "uint";
                case "GLboolean": return "bool";
                case "GLbitfield": return "uint";
                case "GLvoid": return "void";
                case "GLbyte": return "sbyte";
                case "GLshort": return "short";
                case "GLint": return "int";
                case "GLclampx": return "int";
                case "GLubyte": return "byte";
                case "GLushort": return "ushort";
                case "GLuint": return "uint";
                case "GLsizei": return "int";
                case "GLfloat": return "float";
                case "GLclampf": return "float";
                case "GLdouble": return "double";
                case "GLclampd": return "double";
                case "GLeglImageOES": return "void*";
                case "GLchar": return "char";
                case "GLcharARB": return "char";
                case "GLhalf": return "ushort";
                case "GLhalfARB": return "ushort";
                case "GLfixed": return "int";
                case "GLintptr": noPtr = true; return "IntPtr";
                case "GLsizeiptr": noPtr = true; return "IntPtr";
                case "GLintptrARB": noPtr = true; return "IntPtr";
                case "GLsizeiptrARB": noPtr = true; return "IntPtr";
                case "GLint64": return "long";
                case "GLuint64": return "ulong";
                case "GLsync": noPtr = true; return "IntPtr";
                default:
                    Console.Error.WriteLine($"Unknown type: {type}");
                    return $"__UNKNOWN__{type}";
            }
        }

        private static Parameter[] ParseParameters(XmlElement commandElem) 
        {
            List<Parameter> parameters = new List<Parameter>();
            XmlNodeList paramNodes = commandElem.SelectNodes("param");

            for (int i = 0; i < paramNodes.Count; i++)
            {
                XmlNode param = paramNodes[i];
                bool isPointer = param.InnerText.Contains("*");
                string type = param["ptype"] != null ? param["ptype"].InnerText.Trim() : "GLvoid";
                string name = param["name"].InnerText.Trim();

                if (RESERVED_KEYWORDS.Contains(name))
                    name = $"@{name}";

                type = ConvertType(type, out bool noPtr);
                if (noPtr) isPointer = false;

                parameters.Add(new Parameter()
                {
                    Name = name,
                    Type = type,
                    IsPointer = isPointer
                });
            }

            return parameters.ToArray();
        }

        private static Dictionary<string, Command> ParseCommands(XmlElement registryElem)
        {
            Dictionary<string, Command> commands = new Dictionary<string, Command>();

            foreach (XmlElement commandElem in registryElem["commands"].ChildNodes)
            {
                XmlElement proto = commandElem["proto"];
                bool isPointer = proto.InnerText.Contains("*");
                string name = proto["name"].InnerText.Trim();
                string returnType = proto["ptype"] != null ? proto["ptype"].InnerText.Trim() : "GLvoid";

                returnType = ConvertType(returnType, out bool noPtr);
                if (noPtr) isPointer = false;

                commands[name] = new Command()
                {
                    Name = name,
                    ReturnType = returnType,
                    IsPointer = isPointer,
                    Parameters = ParseParameters(commandElem)
                };
            }

            return commands;
        }

        private static Dictionary<string, string> ParseEnums(XmlElement registryElem) 
        {
            Dictionary<string, string> enums = new Dictionary<string, string>();

            foreach (XmlElement enumsElement in registryElem.SelectNodes("enums")) 
            {
                foreach (XmlElement enumElement in enumsElement.SelectNodes("enum"))
                {
                    string name = enumElement.GetAttribute("name").Trim();
                    string value = enumElement.GetAttribute("value").Trim();
                    enums[name] = value;
                }
            }

            return enums;
        }

        private static Feature ParseFeature(XmlElement[] featureElems,
            Dictionary<string, Command> allCommands, Dictionary<string, string> allEnums)
        {
            List<string> enumsRaw = new List<string>();
            List<string> commandsRaw = new List<string>();
            Dictionary<string, string> enums = new Dictionary<string, string>();
            List<Command> commands = new List<Command>();

            foreach (XmlElement featureElem in featureElems) 
            {
                foreach (XmlElement requiredEnum in featureElem.SelectNodes("require//enum"))
                    enumsRaw.AddUnique(requiredEnum.GetAttribute("name"));
                foreach (XmlElement requiredCommand in featureElem.SelectNodes("require//command"))
                    commandsRaw.AddUnique(requiredCommand.GetAttribute("name"));
                foreach (XmlElement removedEnum in featureElem.SelectNodes("remove//enum"))
                    enumsRaw.Remove(removedEnum.GetAttribute("name"));
                foreach (XmlElement removedCommand in featureElem.SelectNodes("remove//command"))
                    commandsRaw.Remove(removedCommand.GetAttribute("name"));
            }

            foreach (string cmd in commandsRaw)
                commands.Add(allCommands[cmd]);
            foreach (string enm in enumsRaw)
                enums[enm] = allEnums[enm];

            return new Feature() 
            {
                Enums = enums,
                Commands = commands
            };
        }

        static void Main(string[] args)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("gl.xml");

            XmlElement registryElem = xmlDoc["registry"];
            Dictionary<string, Command> allCommands = ParseCommands(registryElem);
            Dictionary<string, string> allEnums = ParseEnums(registryElem);
            List<XmlElement> featureElems = new List<XmlElement>();

            foreach (XmlElement featureElem in registryElem.SelectNodes("feature")) 
            {
                string name = featureElem.GetAttribute("name");
                if (!ALLOWED_FEATURES.Contains(name)) continue;
                featureElems.Add(featureElem);
            }

            if (featureElems.Count < 1)
                throw new Exception("Failed to find the feature(s)!?");
            Feature feature = ParseFeature(featureElems.ToArray(), allCommands, allEnums);
            
            FeatureBuilder builder = new FeatureBuilder(feature);
            builder.Build();
            File.WriteAllText("GL.cs", builder.Export());

            Console.ReadLine();
        }
    }
}
