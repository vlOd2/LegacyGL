﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LGLBindingsGen
{
    internal static class ListEx
    {
        public static void AddUnique<T>(this List<T> list, T item) 
        {
            if (list.Contains(item))
                return;
            list.Add(item);
        }
    }
}
