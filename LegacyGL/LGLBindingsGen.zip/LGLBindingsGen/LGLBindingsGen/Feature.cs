﻿using System.Collections.Generic;

namespace LGLBindingsGen
{
    public class Feature
    {
        public Dictionary<string, string> Enums;
        public List<Command> Commands;
    }
}
