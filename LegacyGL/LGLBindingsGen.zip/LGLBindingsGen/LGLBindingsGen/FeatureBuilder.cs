﻿using System.Collections.Generic;

namespace LGLBindingsGen
{
    public class FeatureBuilder
    {
        private Feature feature;
        private EasyStrBuilder builder;

        public FeatureBuilder(Feature feature)
        {
            this.feature = feature;
            builder = new EasyStrBuilder();
        }

        private void BuildEnums(EasyStrBuilder classBuilder) 
        {
            classBuilder.WriteLine("#region Enums");
            foreach (KeyValuePair<string, string> @enum in feature.Enums)
                classBuilder.WriteLine($"public const uint {@enum.Key} = {@enum.Value}u;");
            classBuilder.WriteLine("#endregion");
            classBuilder.WriteLine();
        }

        private void BuildDelegates(EasyStrBuilder classBuilder) 
        {
            classBuilder.WriteLine("#region Delegates");
            foreach (Command cmd in feature.Commands)
            {
                classBuilder.Write($"internal delegate {cmd.ReturnType}");
                if (cmd.IsPointer)
                    classBuilder.Write("*");
                classBuilder.Write($" {cmd.GetDelegateName()}");
                classBuilder.Write("(");

                for (int i = 0; i < cmd.Parameters.Length; i++)
                {
                    Parameter param = cmd.Parameters[i];
                    classBuilder.Write(param.Type);
                    if (param.IsPointer)
                        classBuilder.Write("*");
                    classBuilder.Write($" {param.Name}");
                    if (i != cmd.Parameters.Length - 1)
                        classBuilder.Write(", ");
                }

                classBuilder.WriteLine(");");
            }
            classBuilder.WriteLine("#endregion");
            classBuilder.WriteLine();
        }

        private void BuildHolders(EasyStrBuilder classBuilder) 
        {
            classBuilder.WriteLine("#region Delegate holders");
            foreach (Command cmd in feature.Commands) 
            {
                classBuilder.WriteLine($"[GLAPI(\"{cmd.Name}\")] internal static " +
                    $"{cmd.GetDelegateName()} {cmd.GetHolderName()};");
            }
            classBuilder.WriteLine("#endregion");
            classBuilder.WriteLine();
        }

        private void BuildAPI(EasyStrBuilder classBuilder) 
        {
            classBuilder.WriteLine("#region API");
            foreach (Command cmd in feature.Commands)
            {
                classBuilder.Write($"public static {cmd.ReturnType}");
                if (cmd.IsPointer)
                    classBuilder.Write("*");
                classBuilder.Write($" {cmd.Name}");
                classBuilder.Write("(");

                string invokeParams = "";
                for (int i = 0; i < cmd.Parameters.Length; i++)
                {
                    Parameter param = cmd.Parameters[i];
                    classBuilder.Write(param.Type);
                    if (param.IsPointer)
                        classBuilder.Write("*");
                    classBuilder.Write($" {param.Name}");

                    invokeParams += param.Name;
                    if (i != cmd.Parameters.Length - 1) 
                    {
                        classBuilder.Write(", ");
                        invokeParams += ", ";
                    }
                }

                classBuilder.WriteLine(")");
                classBuilder.WriteLine($"=> {cmd.GetHolderName()}({invokeParams});", 1);
            }
            classBuilder.WriteLine("#endregion");
        }

        public void Build()
        {
            EasyStrBuilder classBuilder = new EasyStrBuilder();

            BuildEnums(classBuilder);
            BuildDelegates(classBuilder);
            BuildHolders(classBuilder);
            BuildAPI(classBuilder);

            builder.WriteLine("// Copyright (c) vlOd");
            builder.WriteLine("// Licensed under the GNU Affero General Public License, version 3.0");
            builder.WriteLine();
            builder.WriteLine("using System;");
            builder.WriteLine("using LegacyGL.Internal;");
            builder.WriteLine();
            builder.WriteLine("#pragma warning disable CS0649");
            builder.WriteLine();
            builder.WriteLine("namespace LegacyGL.OpenGL");
            builder.WriteLine("{");
            builder.WriteLine("public unsafe static class GL", 1);
            builder.WriteLine("{", 1);
            builder.WriteSubBuilder(2, classBuilder.Builder);
            builder.WriteLine("}", 1);
            builder.WriteLine("}");
        }

        public string Export() => builder.Builder.ToString();
    }
}
