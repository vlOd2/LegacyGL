﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace LGLBindingsGen
{
    public class Command
    {
        public string Name;
        public string ReturnType;
        public bool IsPointer;
        public Parameter[] Parameters;
        private string uniqueHash;

        private string UniqueHash()
        {
            if (uniqueHash != null)
                return uniqueHash;
            string data = Name;
            foreach (Parameter param in Parameters) 
                data += $"{param.Type}{param.Name}";
            uniqueHash = BitConverter.ToString(BitConverter.GetBytes(data.GetHashCode()))
                .Replace("-", "").ToLower();
            return uniqueHash;
        }

        public string GetDelegateName()
            => $"__{UniqueHash()}";

        public string GetHolderName()
            => $"_{UniqueHash()}";
    }
}
