﻿using System.Text;

namespace LGLBindingsGen
{
    public class EasyStrBuilder
    {
        public StringBuilder Builder = new StringBuilder();

        public void Indent(int count)
        {
            for (int i = 0; i < count * 4; i++)
                Builder.Append(" ");
        }

        public void Write(string str)
            => Builder.Append(str);

        public void WriteLine(string line = null, int indent = 0)
        {
            if (indent > 0)
                Indent(indent);

            if (line == null)
                Builder.AppendLine();
            else
                Builder.AppendLine(line);
        }

        public void WriteSubBuilder(int indent, StringBuilder subBuilder)
        {
            string[] lines = subBuilder.ToString().Split('\n');

            foreach (string line in lines)
            {
                string l = line.Replace("\r", "").TrimEnd();
                Indent(indent);
                Builder.AppendLine(l);
            }
        }
    }
}
